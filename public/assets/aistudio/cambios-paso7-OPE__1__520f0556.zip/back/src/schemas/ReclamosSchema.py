from typing import Optional
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, ConfigDict

from src.entities.Enums import CategoriaObjeto, EstadoReclamo
from src.utils.imagenes import UrlImagen


class ReclamoBase(BaseModel):
    """Campos base que comparten la creación y lectura de un Reclamo."""

    objetoEnCustodia_id: UUID
    usuario_id: UUID
    evidencia_url: Optional[str] = None
    es_presencial: bool


class ReclamoCreate(BaseModel):
    """Esquema utilizado para crear un nuevo Reclamo."""

    objetoEnCustodia_id: UUID
    es_presencial: bool
    evidencia_url: UrlImagen = None


class ReclamoUpdate(BaseModel):
    """Esquema para actualizar un Reclamo existente (ej. cuando se revisa)."""

    estado: Optional[EstadoReclamo] = None
    fecha_revision: Optional[datetime] = None
    motivo_rechazo: Optional[str] = None
    fecha_cita: Optional[datetime] = None
    horario_cita: Optional[str] = None


class ReclamoResponse(ReclamoBase):
    """Esquema para devolver la información de un Reclamo."""

    reclamo_id: UUID
    estado: EstadoReclamo
    fecha_envio: datetime
    fecha_revision: Optional[datetime] = None
    motivo_rechazo: Optional[str] = None
    fecha_cita: Optional[datetime] = None
    horario_cita: Optional[str] = None
    # Datos del objeto reclamado (sin detalles internos), para que el ciudadano
    # reconozca su reclamo aunque el objeto ya no sea público.
    objeto_categoria: Optional[CategoriaObjeto] = None
    objeto_descripcion: Optional[str] = None
    objeto_imagen_url: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
