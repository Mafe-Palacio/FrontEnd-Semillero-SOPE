from datetime import date, datetime
from enum import Enum
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field
from src.utils.imagenes import UrlImagen


class CategoriaObjeto(str, Enum):
    """Categorías generales para clasificación de objetos."""

    ELECTRONICOS = "ELECTRONICOS"
    DOCUMENTOS = "DOCUMENTOS"
    ROPA = "ROPA"
    ACCESORIOS = "ACCESORIOS"
    BILLETERAS_Y_MONEDEROS = "BILLETERAS_Y_MONEDEROS"
    BOLSOS_Y_MALETAS = "BOLSOS_Y_MALETAS"
    LLAVES = "LLAVES"
    LIBROS_Y_UTILES = "LIBROS_Y_UTILES"
    TERMOS_Y_CONTENEDORES = "TERMOS_Y_CONTENEDORES"
    CASCOS = "CASCOS"
    OTROS = "OTROS"


class EstadoPublicacion(str, Enum):
    """Estados del ciclo de vida y moderación de una publicación."""

    PENDIENTE = "PENDIENTE"
    APROBADA = "APROBADA"
    RECHAZADA = "RECHAZADA"
    ELIMINACION_PENDIENTE = "ELIMINACION_PENDIENTE"
    CERRADA = "CERRADA"


class PublicacionEncontradoBase(BaseModel):
    """Información base para registrar el reporte de un objeto encontrado."""

    categoria: CategoriaObjeto
    descripcion: str
    lugar_hallazgo_id: UUID
    lugar_entrega_fisica_id: UUID
    fecha_hallazgo: date
    imagen_url: Optional[str] = None


class PublicacionEncontradoCreate(PublicacionEncontradoBase):
    """Datos requeridos para publicar un reporte de objeto hallado."""

    imagen_url: UrlImagen = None


class PublicacionEncontradoUpdate(BaseModel):
    """Campos permitidos para la edición administrativa (HU07)."""

    categoria: Optional[CategoriaObjeto] = None
    descripcion: Optional[str] = None
    imagen_url: UrlImagen = None


class PublicacionEncontradoModeracion(BaseModel):
    """Usado por la administradora para aprobar/rechazar (HU02)."""

    estado: EstadoPublicacion
    motivo_rechazo: Optional[str] = None


class PublicacionEncontradoResolverEliminacion(BaseModel):
    """Resuelve la solicitud de eliminación hecha por el usuario dueño de la publicación."""

    aprobar: bool
    motivo: Optional[str] = None


class PublicacionEncontradoSolicitudEliminacion(BaseModel):
    """Cuerpo opcional de la solicitud de baja: el motivo que ve la administración."""

    motivo: Optional[str] = Field(default=None, max_length=500)


class PublicacionEncontradoResponse(PublicacionEncontradoBase):
    """Esquema de respuesta pública con los datos completos de la publicación de hallazgo."""

    publicacionEncontrado_id: UUID
    usuario_id: UUID
    estado: EstadoPublicacion
    fecha_publicacion: datetime
    motivo_rechazo: Optional[str] = None
    eliminacion_solicitada: bool
    motivo_eliminacion: Optional[str] = None
    fecha_edicion: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class PublicacionEncontradoPublico(BaseModel):
    """Vista filtrada para el catálogo general (HU01): oculta la
    descripción libre, igual que ObjetoEnCustodiaPublico oculta
    detalles_internos y ReportePerdidaPublico oculta su descripción."""

    publicacionEncontrado_id: UUID
    categoria: CategoriaObjeto
    lugar_hallazgo_id: UUID
    lugar_hallazgo_nombre: Optional[str] = None
    lugar_entrega_fisica_id: UUID
    lugar_entrega_fisica_nombre: Optional[str] = None
    fecha_hallazgo: date
    imagen_url: Optional[str] = None
    estado: EstadoPublicacion

    model_config = ConfigDict(from_attributes=True)